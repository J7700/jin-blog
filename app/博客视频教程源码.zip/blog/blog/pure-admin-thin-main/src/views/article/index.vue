<script lang="ts" setup>
import { onMounted, reactive, ref } from "vue";
import { Search, RefreshLeft } from "@element-plus/icons-vue";
import { getArticleList } from "@/api/article";

const originalParams = () => ({
  title: "",
  desc: "",
  category: "",
  tag: [],
  createTime: ["", ""],
  currentPage: 1,
  pageSize: 10
});
const total = ref(0);

const tagList = [
  {
    label: "Vue",
    value: "vue"
  },
  {
    label: "Js",
    value: "js"
  }
];

const categoryList = [
  {
    label: "博客部署",
    value: "boke"
  }
];

const params = reactive(originalParams());

const tableData = ref<any>([]);

const handleSearch = () => {
  conditionGetArticleList();
};

const handleReset = () => {
  Object.assign(params, originalParams());
  conditionGetArticleList();
};

const conditionGetArticleList = async () => {
  const res = await getArticleList(params);

  if (res.success || res.code == 200) {
    tableData.value = res.result.list;
    total.value = res.result.total;
  }
};

onMounted(() => {
  conditionGetArticleList();
});
</script>

<template>
  <el-card>
    <template #header> 文章列表 </template>
    <el-form :label-width="72" label-suffix=":">
      <el-row :gutter="20">
        <el-col :sm="8" :xs="12">
          <el-form-item label="标题">
            <el-input v-model="params.title" />
          </el-form-item>
        </el-col>
        <el-col :sm="8" :xs="12">
          <el-form-item label="描述">
            <el-input v-model="params.desc" />
          </el-form-item>
        </el-col>
        <el-col :sm="8" :xs="12">
          <el-form-item label="分类">
            <el-select v-model="params.category" size="large">
              <el-option
                v-for="item in categoryList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :sm="8" :xs="12">
          <el-form-item label="标签">
            <el-select v-model="params.tag" multiple size="large">
              <el-option
                v-for="item in tagList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :sm="8" :xs="12">
          <el-form-item label="发布时间">
            <el-time-picker
              v-model="params.createTime"
              is-range
              range-separator="到"
              start-placeholder="开始时间"
              end-placeholder="结束时间"
            />
          </el-form-item>
        </el-col>
        <el-col :sm="8" :xs="12">
          <el-form-item>
            <el-button :icon="Search" type="primary" @click="handleSearch"
              >搜索</el-button
            >
            <el-button :icon="RefreshLeft" @click="handleReset">重置</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <el-table :data="tableData" style="width: 100%" border>
      <el-table-column type="index" width="50" />
      <el-table-column prop="article_title" label="标题" width="120" />
      <el-table-column
        prop="article_description"
        label="描述"
        width="120"
        show-overflow-tooltip
      />
      <el-table-column prop="article_cover" label="封面" align="center">
        <template #default="{ row, $index }">
          <div class="w-[100%] h-[80px] overflow-hidden">
            <el-image
              class="w-[100%] h-[100%]"
              fit="cover"
              :src="row.article_cover"
              :preview-src-list="tableData.map(v => v.article_cover)"
              :initial-index="$index"
            />
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="article_category" label="分类" width="100">
        <template #default="{ row }">
          {{ row.category.category_name }}
        </template>
      </el-table-column>
      <el-table-column prop="article_tag" label="标签" width="120">
        <template #default="{ row }">
          <el-tag v-for="item in row.tagList" :key="item.id">
            {{ item.tag_name }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="createdAt" label="创建时间" />
      <el-table-column fixed="right" label="操作" width="120">
        <template #default>
          <el-button link type="primary" size="small">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      v-model:current-page="params.currentPage"
      v-model:page-size="params.pageSize"
      :page-sizes="[1, 10, 20, 50]"
      :background="true"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total"
      @change="handleSearch"
    />
  </el-card>
</template>
