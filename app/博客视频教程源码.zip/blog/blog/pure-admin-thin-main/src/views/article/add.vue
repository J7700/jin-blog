<script setup>
import { ref, reactive, onMounted } from "vue";
import { MdEditor } from "md-editor-v3";
import "md-editor-v3/lib/style.css";
import { addArticle } from "@/api/article";
import { getTagList } from "@/api/tag";
import { getCategoryList } from "@/api/category";
import { upLoadImage } from "@/api/upload";

import { message } from "@/utils/message";

const originalArticle = () => ({
  article_title: "",
  category_id: "",
  tagList: [],
  author_id: 1,
  article_content: "",
  article_cover: "",
  article_description: "",
  article_cover: "",
  origin_url: ""
});
const articleFormRef = ref(null);
const articleForm = reactive(originalArticle());
const rules = reactive({
  article_title: [
    { required: true, message: "请输入文章标题", trigger: "blur" }
  ],
  article_content: [
    { required: true, message: "请输入文章内容", trigger: "blur" }
  ],
  article_description: [
    { required: true, message: "请输入文章描述", trigger: "blur" }
  ]
});
const dialogVisible = ref(false);
const fileList = ref([]);

const tagList = ref([]);

const categoryList = ref([]);

const add = () => {
  articleFormRef.value.validate((valid, fields) => {
    if (valid) {
      console.log(articleForm);
      dialogVisible.value = true;
    } else {
      console.log(fields);
      message("请根据提示完善文章信息", {
        type: "warning"
      });
    }
  });
};

const handleClose = () => {
  articleFormRef.value && articleFormRef.value.resetFields();
  Object.assign(articleForm, originalArticle());
  dialogVisible.value = false;
};

const submit = () => {
  // 先获取 fileList里的图片 调后端的接口上传图片 图片上传完成返回服务端的图片地址
  // 图片地址塞进 articleForm.cover
  console.log(articleForm);
  articleFormRef.value.validate(async (valid, fields) => {
    if (valid) {
      // 上传数据
      await uploadCover();
      if (articleForm.article_cover) {
        // 绑定 tag的id

        let list = [];
        list = articleForm.tagList.map(item => {
          if (typeof item === "number") {
            return {
              id: item,
              tag_name: tagList.value.find(tag => tag.id === item).tag_name
            };
          } else {
            return {
              tag_name: item
            };
          }
        });

        articleForm.tagList = list;

        //  图片上传成功以后我们才上传文章的信息
        addArticle(articleForm).then(res => {
          if (res.success) {
            message("新增文章成功", {
              type: "success"
            });
            handleClose();
          }
        });
      }
    } else {
      message("请根据提示完善文章信息", {
        type: "warning"
      });
    }
  });
};

const uploadCover = () => {
  return new Promise((resolve, reject) => {
    if (!fileList.value.length) {
      message("请上传文章封面", {
        type: "warning"
      });
    }

    const formData = new FormData();
    formData.append("file", fileList.value[0].raw);

    upLoadImage(formData).then(res => {
      articleForm.article_cover = res.result.url;
      resolve();
    });
  });
};

const getAllTag = () => {
  getTagList({ findAll: true }).then(res => {
    if (res.success) {
      tagList.value = res.result;
    }
  });
};

const getAllCategory = () => {
  getCategoryList({ findAll: true }).then(res => {
    if (res.success) {
      categoryList.value = res.result;
    }
  });
};

onMounted(() => {
  getAllTag();
  getAllCategory();
});
</script>

<template>
  <el-card header="新增文章">
    <el-form ref="articleFormRef" :model="articleForm" :rules="rules">
      <el-form-item label="文章标题" prop="article_title">
        <div class="w-[100%] flex items-center">
          <el-input v-model="articleForm.article_title" class="mr-[10px]" />
          <el-button type="danger" @click="add">新增</el-button>
        </div>
      </el-form-item>
      <el-form-item prop="article_content">
        <MdEditor v-model="articleForm.article_content" />
      </el-form-item>
    </el-form>

    <el-dialog
      v-model="dialogVisible"
      title="文章新增"
      width="800"
      :before-close="handleClose"
    >
      <el-form
        v-if="dialogVisible"
        ref="articleFormRef"
        :label-width="120"
        label-suffix=":"
        :model="articleForm"
        :rules="rules"
      >
        <el-form-item label="文章标题">
          {{ articleForm.article_title }}
        </el-form-item>
        <el-form-item label="文章描述" prop="article_description">
          <el-input
            v-model="articleForm.article_description"
            :autosize="{ minRows: 2, maxRows: 4 }"
            type="textarea"
            placeholder="请输入文章描述"
          />
        </el-form-item>
        <el-form-item label="分类" prop="category_id">
          <el-select v-model="articleForm.category_id" size="large">
            <el-option
              v-for="item in categoryList"
              :key="item.id"
              :label="item.category_name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="标签" prop="tagList">
          <el-select
            v-model="articleForm.tagList"
            allow-create
            filterable
            multiple
            size="large"
          >
            <el-option
              v-for="item in tagList"
              :key="item.id"
              :label="item.tag_name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="封面" prop="article_cover">
          <el-upload
            v-model:file-list="fileList"
            list-type="picture-card"
            :auto-upload="false"
            :limit="1"
          >
            +
          </el-upload>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="handleClose">取消</el-button>
          <el-button type="primary" @click="submit"> 提交 </el-button>
        </div>
      </template>
    </el-dialog>
  </el-card>
</template>
