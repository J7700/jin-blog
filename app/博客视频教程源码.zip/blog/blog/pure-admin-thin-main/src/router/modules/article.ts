export default {
  path: "/article",
  redirect: "/article/add",
  meta: {
    icon: "ep:memo",
    showLink: true,
    title: "文章管理",
    rank: 9
  },
  children: [
    {
      path: "/article/add",
      name: "文章新增",
      component: () => import("@/views/article/add.vue"),
      meta: {
        title: "文章新增"
      }
    },
    {
      path: "/article/list",
      name: "文章列表",
      component: () => import("@/views/article/index.vue"),
      meta: {
        title: "文章列表"
      }
    }
  ]
} satisfies RouteConfigsTable;
