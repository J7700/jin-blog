import { http } from "@/utils/http";
export type ArticleResult = {
  code: number;
  success: boolean;
  result: any;
};
export const getArticleList = (data?: object) => {
  return http.request<ArticleResult>("post", "/api/article/list", { data });
};

export const addArticle = (data?: object) => {
  return http.request<ArticleResult>("post", "/api/article/add", { data });
};
