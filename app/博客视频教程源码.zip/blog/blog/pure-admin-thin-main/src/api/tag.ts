import { http } from "@/utils/http";
export type TagResult = {
  code: number;
  success: boolean;
  result: any;
};
export const getTagList = (data?: object) => {
  return http.request<TagResult>("post", "/api/tag/list", { data });
};
