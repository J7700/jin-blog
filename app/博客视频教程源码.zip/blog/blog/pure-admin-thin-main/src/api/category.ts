import { http } from "@/utils/http";
export type CategoryResult = {
  code: number;
  success: boolean;
  result: any;
};
export const getCategoryList = (data?: object) => {
  return http.request<CategoryResult>("post", "/api/category/list", { data });
};
