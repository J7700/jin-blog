import { http } from "@/utils/http";
export type UploadResult = {
  code: number;
  success: boolean;
  result: any;
};
export const upLoadImage = (data?: object) => {
  return http.request<UploadResult>(
    "post",
    "/api/upload/img",
    { data },
    {
      headers: {
        "Content-Type": "multipart/form-data"
      }
    }
  );
};
