import http from "@/config/request";

export const getArticleList = (data) => {
  return http.post("/api/article/list", data);
};

export const getArticleDetailById = (id) => {
  return http.get("/api/article/detail/" + id, {});
};
