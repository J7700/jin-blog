<script setup>
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
import { storeToRefs } from "pinia";
import { articleStore } from "@/store/index.js";

import FaRegularListAlt from "~icons/fa-regular/list-alt";
import FaRegularBookmark from "~icons/fa-regular/bookmark";
import Fa6RegularThumbsUp from "~icons/fa6-regular/thumbs-up";
import Fa6RegularEye from "~icons/fa6-regular/eye";
import Fa6RegularCalendarDays from "~icons/fa6-regular/calendar-days";
import Fa6RegularClock from "~icons/fa6-regular/clock";
import Fa6RegularMoon from "~icons/fa6-regular/moon";

import HomeBg from "@/assets/images/home-banner.jpg";
import MdiChevronDown from "~icons/mdi/chevron-down";

import { debounce } from "@/utils/tool";

const route = useRoute();
const { getArticle } = storeToRefs(articleStore());

const showScrollBottom = ref(true);

const scrollToBottom = () => {
  const homeElement = document.querySelector("#home");

  if (homeElement) {
    document.body.scrollTo({
      top: homeElement.clientHeight,
      behavior: "smooth",
    });
  }
};

const scrollListener = () => {
  if (document.body.scrollTop > 50) {
    showScrollBottom.value = false;
  } else {
    showScrollBottom.value = true;
  }
};

const initScrollEvent = () => {
  document.body.addEventListener("scroll", debounce(scrollListener, 100));
};

onMounted(() => {
  initScrollEvent();
});
</script>

<template>
  <div class="page-header">
    <div id="home" v-if="route.path == '/home'" class="home">
      <el-image :src="HomeBg" class="banner" fit="cover"></el-image>
      <div class="content">
        <div class="title">Blog</div>
        <div class="saying">Never put off till tomorrow what you can do</div>
      </div>
      <div class="mask"></div>
      <div v-if="showScrollBottom" class="scroll-bottom"><MdiChevronDown @click="scrollToBottom" class="w-[2rem] h-[2rem] text-white scroll-icon" /></div>
    </div>
    <div v-else-if="route.path == '/article'" class="article">
      <el-image :src="HomeBg" class="banner" fit="cover"></el-image>
      <div class="content text-white">
        <div class="title mb-3">{{ getArticle.article_title }}</div>
        <div v-if="getArticle" class="info text-md mb-3 flex flex-wrap justify-center items-center max-w-[60vw]">
          <div class="item mr-[0.3rem] flex items-center">
            <Fa6RegularCalendarDays class="w-[1rem] h-[1rem] mr-[0.2rem]" />
            <span>发表于 {{ getArticle.createdAt }}</span>
          </div>
          <div class="item mr-[0.3rem] flex items-center">
            <Fa6RegularClock class="w-[1rem] h-[1rem] mr-[0.2rem]" />
            <span>更新于 {{ getArticle.updatedAt }}</span>
          </div>
          <div class="item mr-[0.3rem] flex items-center">
            <FaRegularListAlt class="w-[1rem] h-[1rem] mr-[0.2rem]" />
            <span>{{ getArticle.category.category_name }}</span>
            ｜
          </div>
          <div class="item mr-[0.3rem] flex items-center">
            <FaRegularBookmark class="w-[1rem] h-[1rem] mr-[0.2rem]" />
            <span>{{ getArticle.tagList.map((v) => v.tag_name).join("、") }}</span>
            ｜
          </div>
          <div class="item mr-[0.3rem] flex items-center">
            <Fa6RegularThumbsUp class="w-[1rem] h-[1rem] mr-[0.2rem]" />
            <span>点赞数 {{ getArticle.thumbs_up_times }}</span>
            ｜
          </div>
          <div class="item mr-[0.3rem] flex items-center">
            <Fa6RegularEye class="w-[1rem] h-[1rem] mr-[0.2rem]" />
            <span>浏览次数 {{ getArticle.view_times }}</span>
          </div>
          <div class="item mr-[0.3rem] flex items-center">
            <Fa6RegularMoon class="w-[1rem] h-[1rem] mr-[0.2rem]" />
            <span>阅读时长 {{ getArticle.reading_duration }}</span>
          </div>
        </div>
      </div>
      <div class="mask"></div>
    </div>
    <div v-else class="other">
      <el-image :src="HomeBg" class="banner" fit="cover"></el-image>
      <div class="content">
        <div class="title">{{ route.name }}</div>
      </div>
      <div class="mask"></div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.page-header {
  width: 100%;

  .home {
    position: relative;
    width: 100%;
    height: 100vh;
    overflow: hidden;

    .scroll-bottom {
      position: absolute;
      left: 50%;
      bottom: 0rem;
      transform: translateX(-50%);
      z-index: 2;

      .scroll-icon {
        cursor: pointer;
        animation: bounce 1.5s infinite;
      }
    }
  }

  .article {
    position: relative;
    width: 100%;
    height: 24rem;
    overflow: hidden;
  }

  .other {
    position: relative;
    width: 100%;
    height: 24rem;
    overflow: hidden;
  }

  .content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    max-width: 60%;
    z-index: 2;

    .title {
      font-size: 2rem;
      font-weight: bold;
      color: #fff;
      text-align: center;
    }

    .saying {
      font-size: 1.4rem;
      color: #fff;
      text-align: center;
    }
  }
}

.banner {
  width: 100%;
  height: 100%;
}

.mask {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.3);
  z-index: 1;
}

@keyframes bounce {
  0%,
  100% {
    transform: translateY(-25%);
    animation-timing-function: cubic-bezier(0.8, 0, 1, 1);
    opacity: 1;
  }
  50% {
    transform: translateY(0);
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    opacity: 0.5;
  }
}
</style>
