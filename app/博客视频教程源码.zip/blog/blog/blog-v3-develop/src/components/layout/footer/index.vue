<script setup></script>

<template>
  <div class="footer-container">
    <div class="flex flex-col justify-center items-center h-[100%]">
      <div class="text-xl text-center mb-[5px]">© 小张的博客 2023</div>
      <img src="https://img.shields.io/badge/Blog-Yes-orange" alt="" />
    </div>
  </div>
</template>

<style lang="scss" scoped></style>
