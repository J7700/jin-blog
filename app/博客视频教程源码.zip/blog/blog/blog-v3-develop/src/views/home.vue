<script setup>
import { onMounted, reactive, ref } from "vue";
import { useRouter } from "vue-router";
import HomeBanner from "@/assets/images/home-banner.jpg";
import FaRegularListAlt from "~icons/fa-regular/list-alt";
import FaRegularBookmark from "~icons/fa-regular/bookmark";
import Fa6RegularThumbsUp from "~icons/fa6-regular/thumbs-up";
import Fa6RegularEye from "~icons/fa6-regular/eye";
import Fa6RegularCalendarDays from "~icons/fa6-regular/calendar-days";
import Fa6RegularClock from "~icons/fa6-regular/clock";

import SimpleIconsTencentqq from "~icons/simple-icons/tencentqq";
import SimpleIconsWechat from "~icons/simple-icons/wechat";
import SimpleIconsBilibili from "~icons/simple-icons/bilibili";
import SimpleIconsGithub from "~icons/simple-icons/github";

import Fa6RegularBell from "~icons/fa6-regular/bell";
import Fa6RegularChartBar from "~icons/fa6-regular/chart-bar";
import BlogImage from "@/components/blog-image/index.vue";

import { getArticleList } from "@/api/article";

const router = useRouter();
const articleList = ref([]);
const params = reactive({
  currentPage: 1,
  pageSize: 5,
});
const total = ref(0);

const conditionGetArticleList = async () => {
  const res = await getArticleList(params);
  if (res.success) {
    articleList.value = res.result.list;
    total.value = res.result.total;
  }
};

const tagList = ["Vue", "Js", "React", "Next", "Node", "Pnpm", "Npm"];

const gotoArticle = (id) => {
  if (!id) return;
  router.push({ path: "/article", query: { id } });
};

onMounted(() => {
  conditionGetArticleList();
});
</script>

<template>
  <el-row :gutter="20">
    <el-col :sm="18" :xs="24">
      <el-card class="mb-[1.2rem]" v-for="article in articleList" :key="article.id" shadow="always">
        <div class="article-item w-[100%] md:h-[18rem] 24rem flex md:flex-row flex-col overflow-hidden">
          <div class="article-cover md:w-[45%] md:h-[100%] w-[100%] h-[50%] overflow-hidden">
            <BlogImage @click="gotoArticle(article.id)" :src="article.article_cover" animate />
          </div>
          <div class="article-content md:w-[55%] md:h-[100%] w-[100%] h-[50%] p-[1.2rem] flex flex-col justify-center">
            <div class="title text-3xl mb-5" @click="gotoArticle(article.id)">{{ article.article_title }}</div>
            <div class="info text-sm mb-3 flex flex-wrap items-center">
              <div class="item mr-[0.3rem] flex items-center">
                <Fa6RegularCalendarDays class="w-[1rem] h-[1rem] mr-[0.2rem]" />
                <span>发表于 {{ article.createdAt }}</span>
              </div>
              <div class="item mr-[0.3rem] flex items-center">
                <Fa6RegularClock class="w-[1rem] h-[1rem] mr-[0.2rem]" />
                <span>更新于 {{ article.updatedAt }}</span>
              </div>
              <div class="item mr-[0.3rem] flex items-center">
                <FaRegularListAlt class="w-[1rem] h-[1rem] mr-[0.2rem]" />
                <span>{{ article.category.category_name }}</span>
                ｜
              </div>
              <div class="item mr-[0.3rem] flex items-center">
                <FaRegularBookmark class="w-[1rem] h-[1rem] mr-[0.2rem]" />
                <span>{{ article.tagList.map((v) => v.tag_name).join("、") }}</span>
                ｜
              </div>
              <div class="item mr-[0.3rem] flex items-center">
                <Fa6RegularThumbsUp class="w-[1rem] h-[1rem] mr-[0.2rem]" />
                <span>{{ article.thumbs_up_times }}</span>
                ｜
              </div>
              <div class="item mr-[0.3rem] flex items-center">
                <Fa6RegularEye class="w-[1rem] h-[1rem] mr-[0.2rem]" />
                <span>{{ article.view_times }}</span>
              </div>
            </div>
            <div class="desc text-xl w-[100%] overflow-hidden text-ellipsis whitespace-nowrap">{{ article.article_description }}</div>
          </div>
        </div>
      </el-card>
      <div class="flex justify-center items-center mb-[1.2rem]">
        <el-pagination v-model:current-page="params.currentPage" v-model:page-size="params.pageSize" background layout="prev, pager, next" :total="total" @change="conditionGetArticleList" />
      </div>
    </el-col>
    <el-col :sm="6" :xs="24">
      <el-card class="mb-[1.2rem]">
        <div class="banner w-[100%] h-[8rem]">
          <el-image class="w-[100%] h-[100%]" fit="cover" :src="HomeBanner"></el-image>
        </div>
        <div class="info-box flex items-center p-[0.8rem]">
          <el-avatar :size="48" class="mr-[5px]">M</el-avatar>
          <div>个人博客</div>
        </div>
        <div class="saying p-[0.8rem] text-sm">为什么每天不能睡25个小时啊。</div>
        <div class="flex justify-around items-center p-[1rem]">
          <div class="item">
            <div class="title text-center">文章</div>
            <div class="value text-center">20</div>
          </div>
          <div class="item">
            <div class="title text-center">分类</div>
            <div class="value text-center">20</div>
          </div>
          <div class="item">
            <div class="title text-center">标签</div>
            <div class="value text-center">20</div>
          </div>
        </div>
        <div class="flex justify-around items-center px-[2rem] py-[1rem]">
          <SimpleIconsTencentqq class="w-[1.8rem] h-[1.8rem]" />
          <SimpleIconsWechat class="w-[1.8rem] h-[1.8rem]" />
          <SimpleIconsBilibili class="w-[1.8rem] h-[1.8rem]" />
          <SimpleIconsGithub class="w-[1.8rem] h-[1.8rem]" />
        </div>
      </el-card>
      <el-card class="mb-[1.2rem]">
        <template #header>
          <div class="flex items-center">
            <Fa6RegularBell class="w-[2rem] h-[2rem] mr-[0.3rem]" />
            <div class="text-xl font-bold">公告</div>
          </div>
        </template>
        <div class="p-[1rem]">你好 我有一集</div>
      </el-card>
      <el-affix style="width: inherit" :offset="60">
        <el-card class="mb-[1.2rem]">
          <template #header>
            <div class="flex items-center">
              <FaRegularBookmark class="w-[2rem] h-[2rem] mr-[0.3rem]" />
              <div class="text-xl font-bold">标签</div>
            </div>
          </template>
          <div class="p-[1rem] flex items-center flex-wrap">
            <div class="py-[0.1rem] px-[0.3rem] bg-slate-300 mr-[0.3rem] mb-[0.3rem] rounded-md" v-for="tag in tagList" :key="tag">
              {{ tag }}
            </div>
          </div>
        </el-card>
        <el-card class="mb-[1.2rem]">
          <template #header>
            <div class="flex items-center">
              <Fa6RegularChartBar class="w-[2rem] h-[2rem] mr-[0.3rem]" />
              <div class="text-xl font-bold">网站资讯</div>
            </div>
          </template>
          <div class="p-[1rem] flex flex-col justify-center items-center">
            <div class="item flex justify-between items-center w-[100%]">
              <div class="title text-md">文章数目</div>
              <div class="value text-md">20</div>
            </div>
            <div class="item flex justify-between items-center w-[100%]">
              <div class="title text-md">运行时间</div>
              <div class="value text-md">20天</div>
            </div>
            <div class="item flex justify-between items-center w-[100%]">
              <div class="title text-md">博客访问次数</div>
              <div class="value text-md">20w+</div>
            </div>
          </div>
        </el-card>
      </el-affix>
    </el-col>
  </el-row>
</template>

<style lang="scss" scoped></style>
