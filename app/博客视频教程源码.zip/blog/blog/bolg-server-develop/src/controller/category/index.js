const { result, ERRORCODE, throwError } = require("@/result/index.js");

const { addCategory, updateCategory, deleteCategoryByIds, getCategoryList } = require("@/service/category/index.js");

const errorCode = ERRORCODE.CATEGORY;

class CategoryController {
  async addCategory(ctx) {
    try {
      const { category_name } = ctx.request.body;
      const res = await addCategory(category_name);

      if (res) {
        ctx.body = result("新增分类成功", res);
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "新增分类成功失败"), ctx);
    }
  }

  async updateCategory(ctx) {
    try {
      const { id, category_name } = ctx.request.body;
      const res = await updateCategory(id, category_name);

      if (res) {
        ctx.body = result("修改分类成功", res);
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "修改分类成功失败"), ctx);
    }
  }

  async deleteCategoryByIds(ctx) {
    try {
      const { idList } = ctx.request.body;
      const res = await deleteCategoryByIds(idList);

      ctx.body = result("删除分类成功", res);
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "删除分类失败"), ctx);
    }
  }

  async getCategoryList(ctx) {
    try {
      const res = await getCategoryList(ctx.request.body);

      if (res) {
        ctx.body = result("获取分类列表成功", res);
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "获取分类列表失败"), ctx);
    }
  }
}

module.exports = new CategoryController();
