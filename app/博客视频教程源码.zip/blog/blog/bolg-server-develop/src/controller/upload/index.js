const { result } = require("@/result/index.js");
const path = require("path");

class UploadController {
  async upload(ctx) {
    const { file } = ctx.request.files;
    ctx.body = result("图片上传成功", {
      url: "http://127.0.0.1:8888/local/" + path.basename(file.filepath),
    });
  }
}

module.exports = new UploadController();
