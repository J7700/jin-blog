const { result, ERRORCODE, throwError } = require("@/result/index.js");

const { addTag, updateTag, deleteTagByIds, getTagList } = require("@/service/tag/index.js");

const errorCode = ERRORCODE.CATEGORY;

class TagController {
  async addTag(ctx) {
    try {
      const { tag_name } = ctx.request.body;
      const res = await addTag(tag_name);

      if (res) {
        ctx.body = result("新增标签成功", res);
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "新增标签成功失败"), ctx);
    }
  }

  async updateTag(ctx) {
    try {
      const { id, tag_name } = ctx.request.body;
      const res = await updateTag(id, tag_name);

      if (res) {
        ctx.body = result("修改标签成功", res);
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "修改标签成功失败"), ctx);
    }
  }

  async deleteTagByIds(ctx) {
    try {
      const { idList } = ctx.request.body;
      const res = await deleteTagByIds(idList);

      ctx.body = result("删除标签成功", res);
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "删除标签失败"), ctx);
    }
  }

  async getTagList(ctx) {
    try {
      const res = await getTagList(ctx.request.body);

      if (res) {
        ctx.body = result("获取标签列表成功", res);
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "获取标签列表失败"), ctx);
    }
  }
}

module.exports = new TagController();
