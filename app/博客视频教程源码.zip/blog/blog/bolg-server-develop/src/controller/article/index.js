const { result, ERRORCODE, throwError } = require("@/result/index.js");

const { addArticle, updateArticle, deleteArticleById, getArticleList, getArticleDetailById } = require("@/service/article/index.js");
const { addTag } = require("@/service/tag/index.js");
const { addArticleTag, getTagListByArticleId } = require("@/service/article/articleTag.js");
const { getCategoryById } = require("@/service/category/index.js");

const errorCode = ERRORCODE.CATEGORY;

class ArticleController {
  async addArticle(ctx) {
    try {
      const { tagList, ...rest } = ctx.request.body;

      let promiseList = [];
      const newTagList = [];
      const allTagIdList = [];

      if (Array.isArray(tagList) && tagList.length) {
        tagList.forEach((v) => {
          if (!v.id) {
            newTagList.push(v.tag_name);
          } else {
            allTagIdList.push(v.id);
          }
        });
      }

      if (newTagList.length) {
        promiseList =
          newTagList.length &&
          newTagList.map(async (newTag) => {
            return await addTag(newTag);
          });

        Promise.all(promiseList).then((res) => {
          Array.isArray(res) && res.length > 0 && allTagIdList.push(...res.map((v) => v.id));
        });
      }

      const res = await addArticle(rest);

      if (res) {
        if (res.id && allTagIdList.length) {
          await addArticleTag(res.id, allTagIdList);
        }
        // 对 标签 和 文章 的id 进行绑定
        ctx.body = result("新增文章成功", res);
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "新增文章成功失败"), ctx);
    }
  }

  async getArticleDetailById(ctx) {
    try {
      const id = ctx.params.id;

      const { category_id, ...rest } = await getArticleDetailById(id);
      // tag 中文查询
      const tagList = await getTagListByArticleId(id);
      // category 中文查询
      const category = await getCategoryById(category_id);

      if (rest) {
        ctx.body = result("获取文章详情成功", {
          id,
          ...rest,
          category: category ? { id: category.id, category_name: category.category_name } : null,
          tagList,
        });
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "获取文章详情成功失败"), ctx);
    }
  }

  async updateArticle(ctx) {
    // try {
    //   const { id, article_name } = ctx.request.body;
    //   const res = await updateArticle(id, article_name);
    //   if (res) {
    //     ctx.body = result("修改文章成功", res);
    //   }
    // } catch (err) {
    //   console.log(err);
    //   return ctx.app.emit("error", throwError(errorCode, "修改文章成功失败"), ctx);
    // }
  }

  async deleteArticleById(ctx) {
    // try {
    //   const { idList } = ctx.request.body;
    //   const res = await deleteArticleById(id);
    //   ctx.body = result("删除文章成功", res);
    // } catch (err) {
    //   console.log(err);
    //   return ctx.app.emit("error", throwError(errorCode, "删除文章失败"), ctx);
    // }
  }

  async getArticleList(ctx) {
    try {
      const res = await getArticleList(ctx.request.body);

      if (res) {
        ctx.body = result("获取文章列表成功", res);
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "获取文章列表失败"), ctx);
    }
  }
}

module.exports = new ArticleController();
