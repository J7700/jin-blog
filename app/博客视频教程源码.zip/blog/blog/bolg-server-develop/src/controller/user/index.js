const { createUser, getUserInfo, deleteUserById, updateUserById, getUserPasswordByUsername } = require("@/service/user/index.js");
const { result, throwError, ERRORCODE } = require("@/result/index.js");
const bcrypt = require("bcryptjs"); // 密码加盐加密
const jwt = require("jsonwebtoken");

const errorCode = ERRORCODE.USER;

class UserController {
  async register(ctx) {
    try {
      const params = ctx.request.body;

      const res = await createUser(params);

      if (res) {
        const { password, ...rest } = res;
        ctx.body = result("用户注册成功", rest);
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "用户注册失败"), ctx);
    }
  }

  async getUserInfoById(ctx) {
    try {
      const user_id = ctx.params.id;

      const res = await getUserInfo({ user_id });

      if (res) {
        ctx.body = result("获取用户信息成功", res);
      } else {
        ctx.body = result("用户信息不存在", res);
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "获取用户信息失败"), ctx);
    }
  }

  async userLogin(ctx) {
    try {
      const { username, password } = ctx.request.body;
      const res = await getUserPasswordByUsername(username);

      if (bcrypt.compareSync(password, res.password)) {
        const userInfo = await getUserInfo({ username });

        ctx.body = result("用户登录成功", {
          token: jwt.sign(userInfo, "blog", { expiresIn: "1d" }),
          username: userInfo.username,
          role: userInfo.role,
          id: userInfo.id,
        });
      } else {
        ctx.body = result("密码不匹配");
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "用户名或密码不正确"), ctx);
    }
  }

  // deleteById, updateById

  async deleteUserById(ctx) {
    try {
      const user_id = ctx.params.id;

      const res = await deleteUserById({ id: user_id });

      if (res) {
        ctx.body = result("删除用户成功", res);
      } else {
        ctx.body = result("用户不存在");
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "删除用户成功失败"), ctx);
    }
  }

  async updateUserById(ctx) {
    try {
      const { id, nick_name, avatar } = ctx.request.body;

      const res = await updateUserById({ id, nick_name, avatar });

      if (res) {
        ctx.body = result("修改用户信息成功", res);
      } else {
        ctx.body = result("用户不存在", res);
      }
    } catch (err) {
      console.log(err);
      return ctx.app.emit("error", throwError(errorCode, "修改用户信息成功失败"), ctx);
    }
  }
}

module.exports = new UserController();
