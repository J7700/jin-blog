const path = require("path");
const Koa = require("koa");

const router = require("@/router/index.js");
const onerror = require("koa-onerror");

const { koaBody } = require("koa-body");

const app = new Koa();

// 本地上传
app.use(
  koaBody({
    multipart: true, // 支持文件上传
    formidable: {
      uploadDir: path.join(__dirname, "./upload/local"), // 设置文件上传目录
      keepExtensions: true, // 保持文件的后缀
      maxFieldsSize: 2 * 1024 * 1024, // 文件上传大小
    },
  })
);

// error handler
onerror(app);
app.on("error", (err, ctx) => {
  let status = 500;
  switch (err.code) {
    case "100002":
      // 没有权限
      status = 403;
      break;
    case "100016":
      // token 过期 需要重新登录
      status = 401;
      break;
    default:
      status = 500;
  }
  ctx.status = status;
  ctx.body = err;
  console.error(err);
});

// koa-static 博客图片静态访问
app.use(require("koa-static")(path.join(__dirname, "./upload")));

app.use(router.routes()).use(router.allowedMethods());

module.exports = app;
