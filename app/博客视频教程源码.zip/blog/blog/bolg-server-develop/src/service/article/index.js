const Article = require("@/model/article/article.js");
const { getCategoryById } = require("@/service/category/index.js");
const { getTagListByArticleId } = require("@/service/article/articleTag.js");

class ArticleService {
  // 新建文章
  async addArticle(article) {
    article.createdAt = new Date();
    article.updatedAt = new Date();
    const res = await Article.create(article);

    return res ? res.dataValues : null;
  }

  async getArticleDetailById(id) {
    const res = await Article.findByPk(id);

    return res ? res.dataValues : null;
  }

  async updateArticle(id, article_title) {
    const res = await Article.update(
      {
        article_title,
      },
      {
        where: {
          id,
        },
      }
    );

    return res[0] > 0;
  }

  async deleteArticleByIds(idList) {
    const res = await Article.destroy({
      where: {
        id: idList,
      },
    });

    return res ? res : 0;
  }

  async getArticleList(params) {
    const { pageSize = 10, currentPage = 1, article_title } = params;

    const whereOpt = {};

    article_title && Object.assign(whereOpt, { article_title });

    const limit = pageSize - 0;
    const offset = (currentPage - 1) * limit;

    const { count, rows } = await Article.findAndCountAll({
      limit,
      offset,
      where: whereOpt,
    });

    let promiseCategoryList = [],
      promiseTagList = [];

    // 用于循环查询 分类中文
    promiseCategoryList =
      Array.isArray(rows) &&
      rows.length &&
      rows.map(async (item) => {
        return await getCategoryById(item.dataValues.category_id);
      });

    // 用于循环查询 标签列表中文
    promiseTagList =
      Array.isArray(rows) &&
      rows.length &&
      rows.map(async (item) => {
        return await getTagListByArticleId(item.dataValues.id);
      });

    let categoryResList = [];
    await Promise.all(promiseCategoryList).then((categoryRes) => {
      categoryResList = categoryRes;
    });

    let tagResList = [];
    await Promise.all(promiseTagList).then((tagRes) => {
      tagResList = tagRes;
    });

    // 对应起来
    rows.forEach((v, index) => {
      v.dataValues.category = {
        id: categoryResList[index].id,
        category_name: categoryResList[index].category_name,
      };
      v.dataValues.tagList = tagResList[index];
    });

    return {
      pageSize,
      currentPage,
      total: count,
      list: rows,
    };
  }
}

module.exports = new ArticleService();
