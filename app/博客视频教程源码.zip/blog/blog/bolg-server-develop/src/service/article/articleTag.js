const ArticleTag = require("@/model/article/articleTag.js");

const { getTagById } = require("@/service/tag/index.js");

class ArticleTagService {
  // 新增文章和标签的依赖
  async addArticleTag(articleId, tagIdList) {
    let promiseList = [];

    promiseList =
      Array.isArray(tagIdList) &&
      tagIdList.length &&
      tagIdList.map(async (tagId) => {
        return await ArticleTag.create({
          article_id: articleId,
          tag_id: tagId,
        });
      });

    let result = [];
    await Promise.all(promiseList).then((res) => {
      result = res;
    });

    return result ? result : null;
  }

  // 根据 文章 id 获取 标签列表
  async getTagListByArticleId(articleId) {
    const res = await ArticleTag.findAll({
      where: {
        article_id: articleId,
      },
    });
    let promiseList = [];
    promiseList =
      Array.isArray(res) &&
      res.length &&
      res.map(async (item) => {
        return await getTagById(item.tag_id);
      });
    let result = [];
    await Promise.all(promiseList).then((res) => {
      result =
        Array.isArray(res) && res.length
          ? res.map((tag) => ({
              id: tag.id,
              tag_name: tag.tag_name,
            }))
          : null;
    });

    return result ? result : null;
  }
}

module.exports = new ArticleTagService();
