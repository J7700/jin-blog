const Tag = require("@/model/tag/tag.js");

class TagService {
  // 新建分类
  async addTag(tag_name) {
    const res = await Tag.create({
      tag_name,
    });

    return res ? res.dataValues : null;
  }

  async updateTag(id, tag_name) {
    const res = await Tag.update(
      {
        tag_name,
      },
      {
        where: {
          id,
        },
      }
    );

    return res[0] > 0;
  }

  async deleteTagByIds(idList) {
    const res = await Tag.destroy({
      where: {
        id: idList,
      },
    });

    return res ? res : 0;
  }

  async getTagById(id) {
    const res = await Tag.findOne({
      where: {
        id,
      },
    });

    return res ? res.dataValues : null;
  }

  async getTagList(params) {
    const { pageSize = 10, currentPage = 1, tag_name, findAll = false } = params;

    if (findAll) {
      const res = await Tag.findAll();
      return res;
    }

    const whereOpt = {};

    tag_name && Object.assign(whereOpt, { tag_name });

    const limit = pageSize - 0;
    const offset = (currentPage - 1) * limit;

    const { count, rows } = await Tag.findAndCountAll({
      limit,
      offset,
      where: whereOpt,
    });

    return {
      pageSize,
      currentPage,
      total: count,
      list: rows,
    };
  }
}

module.exports = new TagService();
