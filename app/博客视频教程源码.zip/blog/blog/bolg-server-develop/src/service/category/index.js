const Category = require("@/model/category/category.js");

class CategoryService {
  // 新建分类
  async addCategory(category_name) {
    const res = await Category.create({
      category_name,
    });

    return res ? res.dataValues : null;
  }

  async updateCategory(id, category_name) {
    const res = await Category.update(
      {
        category_name,
      },
      {
        where: {
          id,
        },
      }
    );

    return res[0] > 0;
  }

  async getCategoryById(id) {
    const res = await Category.findOne({
      where: {
        id,
      },
    });

    return res ? res.dataValues : null;
  }

  async deleteCategoryByIds(idList) {
    const res = await Category.destroy({
      where: {
        id: idList,
      },
    });

    return res ? res : 0;
  }

  async getCategoryList(params) {
    const { pageSize = 10, currentPage = 1, category_name, findAll = false } = params;

    if (findAll) {
      const res = await Category.findAll();
      return res;
    }

    const whereOpt = {};

    category_name && Object.assign(whereOpt, { category_name });

    const limit = pageSize - 0;
    const offset = (currentPage - 1) * limit;

    const { count, rows } = await Category.findAndCountAll({
      limit,
      offset,
      where: whereOpt,
    });

    return {
      pageSize,
      currentPage,
      total: count,
      list: rows,
    };
  }
}

module.exports = new CategoryService();
