const User = require("@/model/user/user.js");

class UserService {
  async createUser(params) {
    const res = await User.create(params);

    return res.dataValues;
  }

  async getUserInfo({ username, user_id }) {
    const whereOpt = {};

    username && Object.assign(whereOpt, { username });
    user_id && Object.assign(whereOpt, { id: user_id });

    const res = await User.findOne({
      attributes: { exclude: ["password"] },
      where: whereOpt,
    });

    return res ? res.dataValues : null;
  }

  async getUserPasswordByUsername(username) {
    const res = await User.findOne({
      attributes: ["password"],
      where: {
        username,
      },
    });

    return res ? res.dataValues : null;
  }

  async deleteUserById({ id }) {
    const res = await User.destroy({
      where: {
        id,
      },
    });

    return res ? true : false;
  }

  async updateUserById({ id, nick_name, avatar }) {
    const updateOpt = {};

    nick_name && Object.assign(updateOpt, { nick_name });
    avatar && Object.assign(updateOpt, { avatar });

    const res = await User.update({ nick_name, avatar }, { where: { id } });
    return res[0] > 0 ? true : false;
  }
}

module.exports = new UserService();
