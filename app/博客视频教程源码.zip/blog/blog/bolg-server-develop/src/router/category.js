const Router = require("koa-router");

const router = new Router({ prefix: "/category" });

const { addCategory, updateCategory, deleteCategoryByIds, getCategoryList } = require("@/controller/category/index.js");

// 随便写的一个欢迎
router.post("/add", addCategory);

router.put("/update", updateCategory);

router.post("/delete", deleteCategoryByIds);

router.post("/list", getCategoryList);

module.exports = router;
