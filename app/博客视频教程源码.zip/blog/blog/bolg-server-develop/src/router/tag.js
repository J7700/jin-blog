const Router = require("koa-router");

const router = new Router({ prefix: "/tag" });

const { addTag, updateTag, deleteTagByIds, getTagList } = require("@/controller/tag/index.js");

router.post("/add", addTag);

router.put("/update", updateTag);

router.post("/delete", deleteTagByIds);

router.post("/list", getTagList);

module.exports = router;
