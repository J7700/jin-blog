const Router = require("koa-router");

const router = new Router({ prefix: "/user" });

const { register, getUserInfoById, deleteUserById, updateUserById, userLogin } = require("@/controller/user/index.js");
const { validateUser, bcryptPassword } = require("@/middleware/user.js");

// 随便写的一个欢迎
router.post("/register", validateUser, bcryptPassword, register);
router.get("/getInfoById/:id", getUserInfoById);
router.delete("/deleteById/:id", deleteUserById);
router.post("/updateById", updateUserById);

// 用户登录
router.post("/login", userLogin);

module.exports = router;
