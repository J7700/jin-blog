const Router = require("koa-router");

const router = new Router({ prefix: "/article" });

const { addArticle, getArticleList, getArticleDetailById } = require("@/controller/article/index.js");
const { auth } = require("@/middleware/auth.js");
// 文章新增
router.post("/add", auth, addArticle);
// 文章编辑
// router.put("/update", updateArticle);
// 删除文章
// router.post("/delete", deleteArticleByIds);
// 获取文章列表
router.post("/list", getArticleList);
// 获取文章详情
router.get("/detail/:id", getArticleDetailById);

module.exports = router;
