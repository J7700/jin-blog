const bcrypt = require("bcryptjs"); // 密码加盐加密

const { throwError, ERRORCODE } = require("@/result/index.js");
const { getUserInfo } = require("@/service/user/index.js");
const errorCode = ERRORCODE.USER;
const validateUser = async (ctx, next) => {
  const { username } = ctx.request.body;

  const res = await getUserInfo({ username });
  if (res) {
    return ctx.app.emit("error", throwError(errorCode, "用户账号存在 请重新输入用户账号"), ctx);
  }

  await next();
};

/**
 * 生成加盐的密码
 */
const bcryptPassword = async (ctx, next) => {
  const { password } = ctx.request.body;
  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(password, salt);
  ctx.request.body.password = hash;

  await next();
};

module.exports = {
  validateUser,
  bcryptPassword,
};
