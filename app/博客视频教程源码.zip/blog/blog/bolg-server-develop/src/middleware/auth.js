const jwt = require("jsonwebtoken");

const { ERRORCODE, throwError } = require("@/result/index");
const errorCode = ERRORCODE.AUTH; // 用户权限不足
const tokenErrorCode = ERRORCODE.AUTHTOKEN; // 用户登录过期

const auth = async (ctx, next) => {
  const { authorization } = ctx.request.header;

  const token = authorization ? authorization.replace("Bearer ", "") : undefined;
  if (!authorization) {
    console.error("您没有权限访问，请先登录");
    return ctx.app.emit("error", throwError(tokenErrorCode, "您没有权限访问，请先登录"), ctx);
  }

  try {
    // user 中包含了payload的信息（id，username，role）
    const user = jwt.verify(token, "blog");
    ctx.state.user = user;
  } catch (err) {
    switch (err.name) {
      case "TokenExpiredError":
        console.error("token已过期", err);
        return ctx.app.emit("error", throwError(tokenErrorCode, "token已过期"), ctx);
      case "JsonWebTokenError":
        console.error("无效的token", err);
        return ctx.app.emit("error", throwError(errorCode, "无效的token"), ctx);
    }
  }

  await next();
};

module.exports = {
  auth,
};
